
export interface CulturalItem {
  id: string;
  title: string;
  category: CultureCategory;
  description: string;
  imageUrl: string;
  content: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum CultureCategory {
  HISTORY = '历史足迹',
  ART = '艺术瑰宝',
  SPIRITUALITY = '精神信仰',
  DAILY_LIFE = '高原生活'
}
