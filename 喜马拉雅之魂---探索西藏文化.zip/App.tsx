
import React, { useState } from 'react';
import { HashRouter, Routes, Route, Link } from 'react-router-dom';
import Navbar from './components/Navbar';
import CulturalCard from './components/CulturalCard';
import ChatInterface from './components/ChatInterface';
import { CulturalItem, CultureCategory } from './types';

const INITIAL_ITEMS: CulturalItem[] = [
  {
    id: '1',
    title: '唐卡艺术',
    category: CultureCategory.ART,
    description: '一种挂在墙上供奉的卷轴画，它是西藏文化中一种独具特色的绘画艺术形式。',
    imageUrl: 'https://images.unsplash.com/photo-1544161515-4ad6ce6db874?q=80&w=2070&auto=format&fit=crop',
    content: '唐卡（Thangka）历史悠久，可追溯至吐蕃时期。它不仅是宗教艺术，更是藏族百科全书。唐卡的题材广泛，涉及宗教、历史、政治、医学等多个领域。其绘制工艺极其复杂，通常使用天然矿物颜料，历经数月甚至数年方可完成，色彩亮丽且经久不褪。'
  },
  {
    id: '2',
    title: '布达拉宫',
    category: CultureCategory.HISTORY,
    description: '坐落于拉萨玛布日山上，是世界上海拔最高、最宏伟的宫殿式建筑群。',
    imageUrl: 'https://images.unsplash.com/photo-1512411477724-42b78912d832?q=80&w=2127&auto=format&fit=crop',
    content: '布达拉宫始建于公元7世纪吐蕃王朝赞普松赞干布时期。它分为红宫和白宫两部分，红宫居中，主要是佛殿和历代达赖喇嘛的灵塔殿；白宫环绕四周，是办公及生活场所。这里珍藏着无数的佛像、壁画、珍贵经卷及各种历史文物。'
  },
  {
    id: '3',
    title: '五彩经幡',
    category: CultureCategory.SPIRITUALITY,
    description: '在藏区随处可见的五色旗帜，寄托着人们对吉祥、平安的祈愿。',
    imageUrl: 'https://images.unsplash.com/photo-1524230659192-35f3458f2f7e?q=80&w=2070&auto=format&fit=crop',
    content: '五彩经幡（风马旗）的五种颜色有着严谨的象征意义：蓝色代表蓝天，白色代表白云，红色代表火焰，绿色代表绿水，黄色代表大地。人们相信，风每吹动一次经幡，就等于诵读了一遍经文，祝福将随风传向远方，利益众生。'
  },
  {
    id: '4',
    title: '藏式酥油茶',
    category: CultureCategory.DAILY_LIFE,
    description: '西藏最具代表性的饮品，由酥油、砖茶和盐搅拌而成，是高原生活的必需。',
    imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dad99901?q=80&w=2070&auto=format&fit=crop',
    content: '在气候寒冷、氧气稀薄的高原地区，酥油茶能提供必要的热量和脂肪。藏族谚语云：“茶是肉，茶是血，茶是生命。” 饮用酥油茶已深入藏族社交礼仪，当宾客临门，主人必定会献上一碗香甜可口的酥油茶。'
  }
];

const Home: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<CulturalItem | null>(null);

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden bg-gray-900">
        <img 
          src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=2070&auto=format&fit=crop" 
          className="absolute inset-0 w-full h-full object-cover opacity-60"
          alt="Himalayas"
        />
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <h1 className="text-5xl md:text-8xl font-serif-tibetan font-bold text-white mb-6 drop-shadow-2xl">
            喜马拉雅之魂
          </h1>
          <p className="text-xl md:text-2xl text-white/90 font-light mb-10 tracking-wide max-w-2xl mx-auto leading-relaxed">
            深入雪域高原之心，探索跨越千年的文化瑰宝、神圣艺术与深邃的藏地智慧。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/ai-guide" className="bg-tibetan-red text-white px-8 py-4 rounded-full font-bold hover:bg-red-800 transition-all shadow-lg hover:shadow-red-900/40">
              咨询文化导师
            </Link>
            <button 
              onClick={() => document.getElementById('explore')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white/10 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-full font-bold hover:bg-white/20 transition-all"
            >
              探索文化遗产
            </button>
          </div>
        </div>
      </section>

      {/* Explore Section */}
      <section id="explore" className="max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <span className="text-tibetan-red font-bold uppercase tracking-[0.2em] text-sm mb-4 block">我们的遗产</span>
            <h2 className="text-4xl md:text-5xl font-serif-tibetan font-bold text-gray-900 leading-tight">
              世界屋脊上的<br /><span className="text-tibetan-red">文明瑰宝</span>
            </h2>
          </div>
          <p className="text-gray-500 text-lg max-w-md italic">
            “无论你走到哪里，都要全身心地投入。西藏不仅是一个地方，更是一种境界。”
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {INITIAL_ITEMS.map(item => (
            <CulturalCard key={item.id} item={item} onClick={setSelectedItem} />
          ))}
        </div>
      </section>

      {/* Item Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl">
            <button 
              onClick={() => setSelectedItem(null)}
              className="absolute top-6 right-6 p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors z-10"
            >
              <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            
            <div className="grid md:grid-cols-2">
              <div className="h-64 md:h-full">
                <img src={selectedItem.imageUrl} alt={selectedItem.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-8 md:p-12">
                <span className="text-xs font-bold text-tibetan-red uppercase tracking-widest mb-4 block">
                  {selectedItem.category}
                </span>
                <h2 className="text-3xl md:text-4xl font-serif-tibetan font-bold text-gray-900 mb-6">
                  {selectedItem.title}
                </h2>
                <div className="prose prose-red text-gray-600 space-y-4">
                  <p className="leading-relaxed text-lg italic text-gray-800">
                    {selectedItem.description}
                  </p>
                  <p className="leading-relaxed">
                    {selectedItem.content}
                  </p>
                </div>
                <div className="mt-10 pt-10 border-t border-gray-100">
                  <Link 
                    to="/ai-guide" 
                    onClick={() => setSelectedItem(null)}
                    className="inline-flex items-center text-tibetan-red font-bold gap-2 hover:gap-4 transition-all"
                  >
                    通过 AI 导览了解更多
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Call to Action */}
      <section className="bg-[#fcf9f2] py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="w-20 h-20 bg-tibetan-red text-white flex items-center justify-center rounded-full mx-auto mb-8 text-3xl">
            ☸️
          </div>
          <h2 className="text-3xl md:text-4xl font-serif-tibetan font-bold text-gray-900 mb-8">
            您对西藏文化有任何疑问吗？
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-12 text-lg">
            我们的 AI 文化导览受过数百年的历史与传统知识训练，致力于帮助您探索喜马拉雅文化遗产的深度。
          </p>
          <Link to="/ai-guide" className="inline-block bg-tibetan-red text-white px-10 py-5 rounded-full font-bold text-lg hover:shadow-xl transition-all">
            开启对话
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white/60 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6 text-white">
            <span className="text-2xl font-serif-tibetan font-bold tracking-tight">喜马拉雅之魂</span>
          </div>
          <p className="text-sm">致力于西藏文化遗产的保护、传承与弘扬。</p>
          <div className="mt-8 flex justify-center space-x-6">
            <a href="#" className="hover:text-tibetan-red transition-colors">社交媒体</a>
            <a href="#" className="hover:text-tibetan-red transition-colors">文献资料</a>
            <a href="#" className="hover:text-tibetan-red transition-colors">关于我们</a>
          </div>
          <p className="mt-12 text-xs">© 2024 喜马拉雅之魂 数字文化项目. 技术支持：Gemini AI.</p>
        </div>
      </footer>
    </div>
  );
};

const AIGuidePage: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-[#f7f3e9] px-4 pb-12">
      <div className="max-w-4xl mx-auto mb-10 text-center">
        <h1 className="text-4xl md:text-5xl font-serif-tibetan font-bold text-gray-900 mb-4">文化智库</h1>
        <p className="text-gray-600 text-lg">咨询导师丹增，关于西藏的符号、历史、哲学或高原生活的点滴。</p>
      </div>
      <ChatInterface />
    </div>
  );
};

const GalleryPage: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-white px-4 pb-12">
       <div className="max-w-7xl mx-auto text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-serif-tibetan font-bold text-gray-900 mb-6">高原印象</h1>
        <p className="text-gray-500 max-w-2xl mx-auto text-lg">精心策划的视觉叙事，展现雪域高原各地的风土人情。</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-7xl mx-auto">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="aspect-square overflow-hidden rounded-xl bg-gray-100 relative group">
            <img 
              src={`https://picsum.photos/seed/${i + 50}/800/800`} 
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" 
              alt="Tibetan Scene"
            />
            <div className="absolute inset-0 bg-tibetan-red/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </div>
        ))}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/gallery" element={<GalleryPage />} />
            <Route path="/ai-guide" element={<AIGuidePage />} />
            <Route path="/spirituality" element={
              <div className="pt-32 text-center h-[70vh]">
                <h2 className="text-3xl font-serif-tibetan">精神文化模块 敬请期待</h2>
                <p className="mt-4 text-gray-500">目前正在深度禅定中...</p>
                <Link to="/" className="text-tibetan-red mt-8 inline-block font-bold">返回首页</Link>
              </div>
            } />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
