
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const askCulturalGuide = async (prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[] = []): Promise<string> => {
  const ai = getAIClient();
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: `你叫丹增（Tenzin），是一位博学且谦和的西藏文化、历史与精神信仰专家。
        你的目标是提供深度、准确且具有文化敏感性的西藏相关信息。
        请始终使用平静、尊重且富有智慧的语气。
        当用户问及敏感话题时，请将重心引导至文化遗产的保护、艺术美学以及传统的传承。
        在回答中可以适时引用西藏的传统格言、八吉祥符号及其象征意义或高原的地理特征。
        请全程使用中文回答，并确保内容优美、庄重。`,
        temperature: 0.7,
      },
    });
    return response.text || "非常抱歉，我的禅定被干扰了。请再试一次。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "通往智慧的道路暂时受阻。请检查您的网络连接。";
  }
};
