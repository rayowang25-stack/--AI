
import React from 'react';
import { CulturalItem } from '../types';

interface Props {
  item: CulturalItem;
  onClick: (item: CulturalItem) => void;
}

const CulturalCard: React.FC<Props> = ({ item, onClick }) => {
  return (
    <div 
      onClick={() => onClick(item)}
      className="group relative overflow-hidden rounded-2xl bg-white shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-100"
    >
      <div className="aspect-[4/3] overflow-hidden">
        <img 
          src={item.imageUrl} 
          alt={item.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      <div className="p-5">
        <span className="text-[10px] font-bold uppercase tracking-widest text-tibetan-red mb-2 block">
          {item.category}
        </span>
        <h3 className="text-xl font-serif-tibetan font-bold text-gray-900 mb-2">{item.title}</h3>
        <p className="text-sm text-gray-600 line-clamp-2">{item.description}</p>
      </div>
      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="bg-white/90 p-2 rounded-full shadow-sm">
          <svg className="w-5 h-5 text-tibetan-red" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default CulturalCard;
