
import React, { useState } from 'react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-tibetan-red rounded-full flex items-center justify-center">
              <span className="text-white font-bold">ॐ</span>
            </div>
            <span className="text-xl font-serif-tibetan font-bold tracking-tight text-gray-800">喜马拉雅之魂</span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#/" className="text-gray-600 hover:text-tibetan-red font-medium transition-colors">首页</a>
            <a href="#/gallery" className="text-gray-600 hover:text-tibetan-red font-medium transition-colors">高原影像</a>
            <a href="#/spirituality" className="text-gray-600 hover:text-tibetan-red font-medium transition-colors">精神文化</a>
            <a href="#/ai-guide" className="text-gray-600 hover:text-tibetan-red font-medium transition-colors">AI 导览</a>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600 focus:outline-none">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-gray-100 py-4 px-4 space-y-2">
          <a href="#/" onClick={() => setIsOpen(false)} className="block py-2 text-gray-600 font-medium">首页</a>
          <a href="#/gallery" onClick={() => setIsOpen(false)} className="block py-2 text-gray-600 font-medium">高原影像</a>
          <a href="#/spirituality" onClick={() => setIsOpen(false)} className="block py-2 text-gray-600 font-medium">精神文化</a>
          <a href="#/ai-guide" onClick={() => setIsOpen(false)} className="block py-2 text-gray-600 font-medium">AI 导览</a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
